WC-01 Wall Climber CAD Concept Assets Generated Pack.
